from flask import Flask, request, jsonify
import paho.mqtt.client as mqtt
import json
import requests
import networkx as nx
import logging
import threading
import global_utils.constants as constants
import time as py_time
import random

# Configuração do Gateway HTTP
FABRIC_GATEWAY_URL = "http://localhost:8080"  # Ajuste conforme necessário

# Variável global para o estado do Fabric
fabric_cli = None

def create_server(server_config):
     # Configurações do servidor
    company_name = server_config['company']
    server_name = server_config['name']
    port = server_config['port']
    charging_points = server_config['charging_points']

    charging_points_lock = threading.Lock()

    app = Flask(__name__)
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    logger = logging.getLogger(f'Server_{server_name.upper()}')

    G = nx.Graph()
    G.add_nodes_from(constants.CITYS_NODES)
    G.add_edges_from(constants.CITYS_WEIGHT)

    # MQTT config
    mqtt_broker = constants.mqtt_broker_ip
    mqtt_port = constants.PORTA_MQTT
    mqtt_topic_battery = constants.TOPICO_BATERIA.format(server=f"server_{server_name}")
    mqtt_topic_request = constants.TOPICO_RESERVA.format(server=f"server_{server_name}")
    

    def inicializar_fabric_client():
        """Inicializa a conexão com o Fabric via Gateway HTTP"""
        global fabric_cli
        logger.info("Configurando conexão com Fabric Gateway HTTP...")
        fabric_cli = {
            'gateway_url': FABRIC_GATEWAY_URL,
            'enabled': True
        }
        logger.info("Conexão com Fabric Gateway configurada com sucesso!")

    def enviar_transacao_fabric(tipo, veiculo_id, payload):
        """Envia uma transação para o gateway Fabric"""
        if not fabric_cli or not fabric_cli.get('enabled'):
            logger.warning("Gateway Fabric não está habilitado, transação não será registrada")
            return False
        
        url = f"{fabric_cli['gateway_url']}/api/transacao"
        try:
            response = requests.post(
                url,
                json={
                    "tipo": tipo,
                    "veiculo_id": veiculo_id,
                    "cidade": payload.get("cidade", ""),
                    "ponto_id": payload.get("ponto_id", ""),
                    "empresa": payload.get("empresa", ""),
                    "detalhes": json.dumps(payload),
                    "valor": str(payload.get("valor", "0"))
                },
                timeout=5
            )
            if response.status_code == 201:
                logger.info(f"Transação {tipo} registrada com sucesso para {veiculo_id}")
                return True
            else:
                logger.error(f"Erro ao registrar transação: {response.text}")
                return False
        except Exception as e:
            logger.error(f"Falha ao chamar gateway Fabric: {e}")
            return False

    def consultar_historico_fabric(veiculo_id):
        """Consulta o histórico de um veículo no ledger"""
        if not fabric_cli or not fabric_cli.get('enabled'):
            logger.warning("Gateway Fabric não está habilitado, não é possível consultar histórico")
            return None
        
        url = f"{fabric_cli['gateway_url']}/api/historico/{veiculo_id}"
        try:
            response = requests.get(url, timeout=5)
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"Erro ao consultar histórico: {response.text}")
                return None
        except Exception as e:
            logger.error(f"Falha ao consultar histórico no gateway: {e}")
            return None

    def handle_charging_request(data):

        vehicle_id = data['vehicle_id']
        action = data['action']

        with charging_points_lock:
            if action == 'request':
                logger.info(f'Processing charge request from {vehicle_id}')
                for point in charging_points:
                    if point["location"] == data["location"]:
                        if point["reserved"] < point["capacity"]:
                            point["reserved"] += 1
                            response = {
                                "status": "READY",
                                "point_id": point["id"],
                                "vehicle_id": vehicle_id
                            }
                        else:
                            if vehicle_id not in point["queue"]:
                                point["queue"].append(vehicle_id)
                            response = {
                                "status": "QUEUED",
                                "position": len(point["queue"]),
                                "vehicle_id": vehicle_id
                            }

                        mqtt_client.publish(
                            constants.TOPICO_RESPOSTA.format(vehicle_id=vehicle_id),
                            json.dumps(response),
                            qos=constants.MQTT_QOS
                        )

                        logger.info(f"Queue status for [{point['id']}]-({point['location']}): {point['queue']}")

                        break

            if action == "done":
                point_id = data["point_id"]
                for point in charging_points:
                    if point["id"] == point_id:
                        point["reserved"] = max(0, point["reserved"] - 1)
                        logger.info(f"Point {point_id} at {point['location']} released by {vehicle_id}, reserved: {point['reserved']}")
                        
                        # Registrar recarga no ledger via HTTP
                        energia_kwh = round(random.uniform(20.0, 50.0), 2)
                        custo_brl = round(energia_kwh * 2.5, 2)
                        payload_recarga = {
                            "ponto_id": point_id,
                            "cidade": point["location"],
                            "empresa": company_name,
                            "energia_kwh": energia_kwh,
                            "custo_brl": custo_brl
                        }
                        enviar_transacao_fabric("recarga", vehicle_id, payload_recarga)

                        if point["queue"]:
                            next_vehicle = point["queue"].pop(0)
                            point["reserved"] += 1
                            mqtt_client.publish(
                                constants.TOPICO_RESPOSTA.format(vehicle_id=next_vehicle),
                                json.dumps({
                                    "status": "READY",
                                    "point_id": point_id,
                                    "vehicle_id": next_vehicle
                                }),
                                qos=constants.MQTT_QOS
                            )
                            logger.info(f"Notified next vehicle {next_vehicle} for point {point_id}")
                        break

    def handle_route_request(data):
        vehicle_id = data['vehicle_id']
        city_start = data['start']
        city_end = data['end']

        logger.info(f'{server_name.upper()}: Received route request from {vehicle_id}:\n        Start: {city_start} ====> End: {city_end}')

        result = plan_route_for_vehicle(vehicle_id, city_start, city_end)
        
        response_topic = constants.TOPICO_RESPOSTA.format(vehicle_id=vehicle_id)
        if 'error' in result:
            response = {'status': "ERROR", 'error': result['error']}
        else:
            response = {'status': 'READY', 'route': result['path'], 'reservations': result['reservations']}

        mqtt_client.publish(response_topic, json.dumps(response), qos=constants.MQTT_QOS)
        logger.info(f"{server_name.upper()}: Sent route response to {vehicle_id}")

    def on_connect(client, userdata, flags, rc):
        logger.info(f"{server_name.upper()} connected to MQTT broker with code {rc}")
        client.subscribe(mqtt_topic_battery)
        client.subscribe(mqtt_topic_request)
        client.subscribe(constants.TOPICO_ROUTE_REQUEST.format(server=f"server_{server_name}"))

    def on_message(client, userdata, msg):
        try:
            data = json.loads(msg.payload.decode())
            if msg.topic == mqtt_topic_request:
                handle_charging_request(data)
            elif msg.topic == constants.TOPICO_ROUTE_REQUEST.format(server=f"server_{server_name}"):
                handle_route_request(data)
        except Exception as e:
            logger.error(f"Error processing MQTT message: {e}")

    mqtt_client = mqtt.Client()
    mqtt_client.on_connect = on_connect
    mqtt_client.on_message = on_message
    mqtt_client.connect("mosquitto", 18833, 60)
    mqtt_client.loop_start()

    # list all points from the server
    @app.route('/api/charging_points', methods=['GET'])
    def list_charging_points():
        logger.info(f'{server_name.upper()}: returning charging points')
        return jsonify({company_name: charging_points})

    # prepare phase from the 2pc
    @app.route('/api/prepare', methods=['POST'])
    def prepare_reservation():
        data = request.json
        point_id = data.get("point_id")
        vehicle_id = data.get("vehicle_id")
        
        if not point_id or not vehicle_id:
            return jsonify({"status": "ABORT"}), 400
        
        with charging_points_lock:
            for point in charging_points:
                if point["id"] == point_id:
                    if vehicle_id in point["queue"]:
                        return jsonify({
                            "status": "QUEUED",
                            "position": point["queue"].index(vehicle_id) + 1,
                            "estimated_time": (point["queue"].index(vehicle_id) + 1) * 30
                        })
                    if point["reserved"] < point["capacity"]:
                        point["reserved"] += 1
                        logger.info(f"Server {server_name.upper()}: Prepared reservation for {vehicle_id} at {point_id}")
                        return jsonify({
                            "status": "READY",
                            "position": 0
                        })
                    else:
                        point["queue"].append(vehicle_id)
                        logger.info(f"Server {server_name.upper()}: Queued {vehicle_id} at {point_id}, position {len(point['queue'])}")
                        return jsonify({
                            "status": "QUEUED",
                            "position": len(point["queue"]),
                            "estimated_time": len(point["queue"]) * 30
                        })
            return jsonify({"status": "ABORT"}), 400

    @app.route('/api/commit', methods=['POST'])
    def commit_reservation():
        data = request.json
        point_id = data.get('point_id')
        vehicle_id = data.get('vehicle_id')

        with charging_points_lock:
            for point in charging_points:
                if point['id'] == point_id:
                    if vehicle_id in point['queue']:
                        point['queue'].remove(vehicle_id)
                        point['reserved'] += 1
                    logger.info(f'{server_name.upper()}: Commited reservation for {vehicle_id} in {point_id}')
                    return jsonify({'status': 'COMMITED'})
            return jsonify({'status': 'ABORTED'})
                    
    @app.route('/api/abort', methods=['POST'])
    def abort_reservation():
        data = request.json
        point_id = data.get("point_id")
        vehicle_id = data.get("vehicle_id")
        
        with charging_points_lock:
            for point in charging_points:
                if point["id"] == point_id:
                    if vehicle_id in point["queue"]:
                        point["queue"].remove(vehicle_id)
                        logger.info(f"{server_name.upper()}: Aborted queue reservation for {vehicle_id} at {point_id}")
                    elif point["reserved"] > 0:
                        point["reserved"] -= 1
                        logger.info(f"{server_name.upper()}: Aborted reservation for {vehicle_id} at {point_id}, reserved: {point['reserved']}")
                        if point["queue"]:
                            next_vehicle = point["queue"].pop(0)
                            point["reserved"] += 1
                            mqtt_client.publish(
                                constants.TOPICO_RESPOSTA.format(vehicle_id=next_vehicle),
                                json.dumps({
                                    "status": "READY",
                                    "point_id": point_id,
                                    "vehicle_id": next_vehicle
                                }),
                                qos=constants.MQTT_QOS
                            )
                            logger.info(f"Server {server_name.upper()}: Notified next vehicle {next_vehicle} for point {point_id}")
                    return jsonify({"status": "ABORTED"})
            return jsonify({"status": "ABORTED"})

    # get the queue status from the point
    @app.route('/api/queue_status/<point_id>', methods=['GET'])
    def queue_status(point_id):
        for point in charging_points:
            if point["id"] == point_id:
                return jsonify({
                    "reserved": point["reserved"],
                    "queue_size": len(point["queue"]),
                    "queue": point["queue"]
                })
        return jsonify({"error": "Point not found"}), 404
                    
    # get the charging status from the all points for the server 
    @app.route('/api/charging_status', methods=['GET'])
    def charging_status():
        status = []
        for point in charging_points:
            status.append({
                "id": point["id"],
                "location": point["location"],
                "reserved": point["reserved"],
                "queue_size": len(point["queue"]),
                "queue": point["queue"]
            })
        return jsonify(status)
        
    # function for plan the route for a vehicle with the start and end city
    def plan_route_for_vehicle(vehicle_id, start, end):
        logger.info(f"{server_name.upper()}: Planning route for vehicle {vehicle_id} [{start} => {end}]")
        try:
            path = nx.shortest_path(G, start, end, weight="weight") # get the shortest way with dijkstra
            logger.info(f"{server_name.upper()}: Shortest path: [{path}]")
            
            # List all servers
            servers = {
                s["company"]: constants.SERVERS[s["company"]]["url"]
                for s in constants.servers_port
                if s["company"] != company_name
            }
            reservations = []
            all_prepared = True
            
            # Fase 1: Prepare
            for i in range(len(path)):
                current_city = path[i]
                reserved = False
                
                # Verify local points first
                for point in charging_points:
                    if point["location"] == current_city:
                        if point["reserved"] < point["capacity"]:
                            point["reserved"] += 1
                            reservations.append({
                                "company": company_name,
                                "point_id": point["id"],
                                "city": current_city,
                                "url": None
                            })
                            reserved = True
                            logger.info(f"{server_name.upper()}: Prepared local reservation for {current_city}, point {point['id']}")
                            break
                        else:
                            prepare_response = requests.post(
                                constants.SERVERS[company_name]["url"] + "/api/prepare",
                                json={"point_id": point["id"], "vehicle_id": vehicle_id},
                                timeout=2
                            )
                            if prepare_response.status_code == 200:
                                result = prepare_response.json()
                                if result["status"] == "QUEUED":
                                    reservations.append({
                                        "company": company_name,
                                        "point_id": point["id"],
                                        "city": current_city,
                                        "url": None,
                                        "position": result["position"]
                                    })
                                    reserved = True
                                    break
                
                if not reserved:
                    for other_company, url in servers.items():
                        try:
                            response = requests.get(f"{url}/api/charging_points", timeout=2)
                            if response.status_code == 200:
                                points = response.json().get(other_company, [])
                                for point in points:
                                    if point["location"] == current_city:
                                        prepare_response = requests.post(
                                            f"{url}/api/prepare",
                                            json={"point_id": point["id"], "vehicle_id": vehicle_id},
                                            timeout=2
                                        )
                                        if prepare_response.status_code == 200:
                                            result = prepare_response.json()
                                            if result["status"] == "READY":
                                                reservations.append({
                                                    "company": other_company,
                                                    "point_id": point["id"],
                                                    "city": current_city,
                                                    "url": url
                                                })
                                                reserved = True
                                                break
                                            elif result["status"] == "QUEUED":
                                                reservations.append({
                                                    "company": other_company,
                                                    "point_id": point["id"],
                                                    "city": current_city,
                                                    "url": url,
                                                    "position": result["position"]
                                                })
                                                reserved = True
                                                break
                                if reserved:
                                    break
                        except Exception as e:
                            logger.error(f"{server_name.upper()}: Error contacting {other_company}: {e}")
                            all_prepared = False
                
                if not reserved:
                    all_prepared = False
                    break
            
            # Fase 2: Commit or Abort
            if not all_prepared:
                for r in reservations:
                    if r["company"] == company_name:
                        for point in charging_points:
                            if point["id"] == r["point_id"]:
                                if "position" in r:
                                    if vehicle_id in point["queue"]:
                                        point["queue"].remove(vehicle_id)
                                else:
                                    point["reserved"] = max(0, point["reserved"] - 1)
                    elif r["url"]:
                        try:
                            requests.post(
                                f"{r['url']}/api/abort",
                                json={"point_id": r["point_id"], "vehicle_id": vehicle_id},
                                timeout=2
                            )
                        except Exception as e:
                            logger.error(f"{server_name.upper()}: Error aborting reservation: {e}")
                
                mqtt_client.publish(
                    constants.TOPICO_RESPOSTA.format(vehicle_id=vehicle_id),
                    json.dumps({
                        "status": "ERROR",
                        "server": server_name,
                        "error": "Could not reserve all required points"
                    }),
                    qos=constants.MQTT_QOS
                )
                return {"error": "Could not reserve all required points"}

            for r in reservations:
                if r["company"] == company_name:
                    for point in charging_points:
                        if point["id"] == r["point_id"] and "position" in r:
                            if vehicle_id in point["queue"]:
                                point["queue"].remove(vehicle_id)
                                point["reserved"] += 1
                    logger.info(f"{server_name.upper()}: Committed local reservation for {r['city']}, point {r['point_id']}")
                elif r["url"]:
                    try:
                        requests.post(
                            f"{r['url']}/api/commit",
                            json={"point_id": r["point_id"], "vehicle_id": vehicle_id},
                            timeout=2
                        )
                    except Exception as e:
                        logger.error(f"{server_name.upper()}: Error committing reservation: {e}")
            # <<< SUBSTITUIÇÃO AQUI: REGISTRAR RESERVA NO LEDGER >>>
            if fabric_cli:
                try:
                    tx_id = f"RES-{vehicle_id}-{int(py_time.time())}"
                    payload_reserva = {"rota": path, "reservas_detalhadas": reservations}
                    payload_str = json.dumps(payload_reserva)

                    logger.info(f"Submetendo transação de RESERVA para o ledger: {tx_id}")
                    # Sintaxe nova para submeter transação
                    fabric_cli.get_channel('mychannel').execute_chaincode(
                        'ev_charging', 'RegistrarTransacao', [tx_id, "RESERVA", vehicle_id, payload_str]
                    )
                    logger.info(" Transação de RESERVA submetida com sucesso ao ledger.")
                except Exception as e:
                    logger.error(f" Falha ao submeter transação de RESERVA: {e}")

            mqtt_client.publish(
                constants.TOPICO_RESPOSTA.format(vehicle_id=vehicle_id),
                json.dumps({
                    "status": "READY",
                    "point_id": reservations[0]["point_id"],
                    "city": reservations[0]["city"],
                    "server": server_name,
                    "route": path,
                    "reservations": [{
                        "company": r["company"],
                        "point_id": r["point_id"],
                        "city": r["city"],
                        "position": r.get("position", 0)
                    } for r in reservations]
                }),
                qos=constants.MQTT_QOS
            )
            
            return {
                "path": path,
                "reservations": [{
                    "company": r["company"],
                    "point_id": r["point_id"],
                    "city": r["city"],
                    "position": r.get("position", 0)
                } for r in reservations]
            }
            
        except Exception as e:
            logger.error(f"Server {server_name.upper()}: Route planning error: {e}")
            mqtt_client.publish(
                constants.TOPICO_RESPOSTA.format(vehicle_id=vehicle_id),
                json.dumps({
                    "status": "ERROR",
                    "server": server_name,
                    "error": str(e)
                }),
                qos=constants.MQTT_QOS
            )
            return {"error": str(e)}

    # endpoint for use the plan route function
    @app.route('/api/plan_route', methods=['POST'])
    def plan_route():
        data = request.json
        start = data.get("start")
        end = data.get("end")
        vehicle_id = data.get("vehicle_id")
        
        if not start or not end or not vehicle_id:
            logger.error(f"Server {server_name.upper()}: Missing start, end, or vehicle_id")
            return jsonify({"error": "Missing start, end, or vehicle_id"}), 400
        
        result = plan_route_for_vehicle(vehicle_id, start, end)
        return jsonify(result)
    @app.route('/api/payment', methods=['POST'])
    def process_payment():
        data = request.json
        vehicle_id = data.get("vehicle_id")
        amount = data.get("amount")
        
        if not vehicle_id or amount is None:
            return jsonify({"error": "vehicle_id e amount são obrigatórios"}), 400

        payload_pagamento = {
            "valor_pago_brl": amount,
            "cidade": "N/A",
            "ponto_id": "N/A"
        }
        if enviar_transacao_fabric("pagamento", vehicle_id, payload_pagamento):
            return jsonify({"status": "PAGAMENTO_REGISTRADO"}), 201
        else:
            return jsonify({"error": "Falha ao registrar pagamento"}), 500

    # Dentro de generic_server.py, junto com suas outras rotas @app.route(...)

    # Modifique o endpoint de histórico para:
    @app.route('/api/historico/<id_veiculo>', methods=['GET'])
    def consultar_historico(id_veiculo):
        """Endpoint para consultar histórico no ledger via gateway"""
        logger.info(f"Consultando histórico para veículo: {id_veiculo}")
        
        historico = consultar_historico_fabric(id_veiculo)
        if historico is None:
            return jsonify({"erro": "Não foi possível consultar o histórico"}), 500
        
        return jsonify(historico), 200

    
    inicializar_fabric_client()
    return app, port

if __name__ == '__main__':
    print('Working')
