package main

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"os"

	"github.com/gorilla/mux"
	"github.com/hyperledger/fabric-sdk-go/pkg/gateway"
)

var contract *gateway.Contract

func main() {
	// Carregar Wallet e conexão com Gateway
	wallet, err := gateway.NewFileSystemWallet("wallet")
	if err != nil {
		log.Fatalf("Erro ao carregar wallet: %v", err)
	}

	ccpPath := "connection.yaml"

	gw, err := gateway.Connect(
		gateway.WithConfig(gateway.ConfigFromYAMLFile(ccpPath)),
		gateway.WithIdentity(wallet, "admin"),
	)
	if err != nil {
		log.Fatalf("Erro ao conectar gateway: %v", err)
	}
	defer gw.Close()

	network, err := gw.GetNetwork("mychannel")
	if err != nil {
		log.Fatalf("Erro ao acessar canal: %v", err)
	}

	contract = network.GetContract("ev_charging") // Nome do chaincode

	// Criar API HTTP
	r := mux.NewRouter()
	r.HandleFunc("/api/transacao", registrarTransacao).Methods("POST")
	r.HandleFunc("/api/historico/{veiculo_id}", consultarHistorico).Methods("GET")

	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}

	fmt.Printf("API ouvindo na porta %s...\n", port)
	log.Fatal(http.ListenAndServe(":"+port, r))
}

type Transacao struct {
	Tipo      string `json:"tipo"`
	VeiculoID string `json:"veiculo_id"`
	Cidade    string `json:"cidade"`
	PontoID   string `json:"ponto_id"`
	Empresa   string `json:"empresa"`
	Detalhes  string `json:"detalhes"`
	Valor     string `json:"valor"`
}

func registrarTransacao(w http.ResponseWriter, r *http.Request) {
	var t Transacao
	err := json.NewDecoder(r.Body).Decode(&t)
	if err != nil {
		http.Error(w, "Erro no JSON", http.StatusBadRequest)
		return
	}

	tipoMap := map[string]string{
		"reserva":   "0",
		"recarga":   "1",
		"pagamento": "2",
	}
	tipoInt, ok := tipoMap[t.Tipo]
	if !ok {
		http.Error(w, "Tipo inválido", http.StatusBadRequest)
		return
	}

	_, err = contract.SubmitTransaction(
		"RegistrarTransacao",
		tipoInt, t.VeiculoID, t.Cidade, t.PontoID, t.Empresa, t.Detalhes, t.Valor,
	)
	if err != nil {
		http.Error(w, fmt.Sprintf("Erro ao registrar transação: %v", err), http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusCreated)
	w.Write([]byte(" Transação registrada com sucesso"))
}

func consultarHistorico(w http.ResponseWriter, r *http.Request) {
	params := mux.Vars(r)
	veiculoID := params["veiculo_id"]

	result, err := contract.EvaluateTransaction("ConsultarHistoricoVeiculo", veiculoID)
	if err != nil {
		http.Error(w, fmt.Sprintf("Erro ao consultar histórico: %v", err), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.Write(result)
}
