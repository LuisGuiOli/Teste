// Salve este arquivo como "smartcontract.go"
package recargascarroseletricosmain

import (
	"encoding/json" // Necessário para converter os dados para e de JSON
	"fmt"           // Usado para formatar e imprimir erros
	"time"          // Usado para gerar timestamps

	// Pacote principal da API de Contrato do Hyperledger Fabric para Go
	"github.com/hyperledger/fabric-contract-api-go/v2/contractapi"
)

// SmartContract define a estrutura do nosso contrato inteligente, que conterá nossas funções.
type SmartContract struct {
	contractapi.Contract
}

// Transacao representa a unidade fundamental de registro no nosso ledger.
// É uma estrutura genérica para armazenar qualquer evento importante.
type Transacao struct {
	ID        string `json:"ID"`        // ID único da transação (ex: "RES-123", "REC-456")
	Tipo      string `json:"Tipo"`      // Tipo do evento: "RESERVA", "RECARGA", "PAGAMENTO"
	IDVeiculo string `json:"IDVeiculo"` // ID do veículo para rastrear o histórico
	Timestamp string `json:"Timestamp"` // Momento em que a transação foi registrada (em formato UTC)
	Payload   string `json:"Payload"`   // String JSON com os detalhes específicos da transação
}

// InitLedger é uma função para inicializar o ledger com dados de exemplo.
// Ótima para testar a rede e o chaincode sem precisar de uma aplicação cliente.
func (s *SmartContract) InitLedger(ctx contractapi.TransactionContextInterface) error {
	// Cria uma lista de transações de exemplo
	transacoes := []Transacao{
		{
			ID:        "RESERVA-001",
			Tipo:      "RESERVA",
			IDVeiculo: "veiculo-teste-007",
			Timestamp: time.Now().UTC().Format(time.RFC3339),
			Payload:   `{"origem":"João Pessoa", "destino":"Recife", "pontos_reservados":["PONTO-JPA-01", "PONTO-REC-03"]}`,
		},
		{
			ID:        "RECARGA-001",
			Tipo:      "RECARGA",
			IDVeiculo: "veiculo-teste-007",
			Timestamp: time.Now().UTC().Format(time.RFC3339),
			Payload:   `{"ponto_id":"PONTO-JPA-01", "empresa":"company_e", "energia_kwh":35.2, "custo_brl":88.00}`,
		},
		{
			ID:        "PAGAMENTO-001",
			Tipo:      "PAGAMENTO",
			IDVeiculo: "veiculo-teste-007",
			Timestamp: time.Now().UTC().Format(time.RFC3339),
			Payload:   `{"valor_pago_brl":88.00, "recargas_pagas":["RECARGA-001"]}`,
		},
	}

	// Itera sobre a lista e salva cada transação no ledger
	for _, tx := range transacoes {
		txJSON, err := json.Marshal(tx)
		if err != nil {
			return err // Se a conversão para JSON falhar, retorna o erro
		}

		// PutState é o comando que efetivamente escreve os dados no ledger
		err = ctx.GetStub().PutState(tx.ID, txJSON)
		if err != nil {
			return fmt.Errorf("falha ao inserir no world state: %v", err)
		}
	}

	return nil
}

// RegistrarTransacao é a principal função de escrita. Ela cria uma nova transação no ledger.
// Será chamada pelo seu servidor Python quando uma reserva, recarga ou pagamento ocorrer.
func (s *SmartContract) RegistrarTransacao(ctx contractapi.TransactionContextInterface, id string, tipo string, idVeiculo string, payload string) error {
	// Primeiro, verifica se uma transação com este ID já existe para evitar duplicatas
	exists, err := s.TransacaoExists(ctx, id)
	if err != nil {
		return err
	}
	if exists {
		return fmt.Errorf("a transação %s já existe", id)
	}

	// Cria a struct da transação com os dados recebidos
	transacao := Transacao{
		ID:        id,
		Tipo:      tipo,
		IDVeiculo: idVeiculo,
		Timestamp: time.Now().UTC().Format(time.RFC3339), // Gera o timestamp no momento da criação
		Payload:   payload,
	}

	// Converte a struct para o formato JSON
	transacaoJSON, err := json.Marshal(transacao)
	if err != nil {
		return err
	}

	// Salva a transação no ledger
	return ctx.GetStub().PutState(id, transacaoJSON)
}

// ConsultarTransacao busca e retorna uma transação específica pelo seu ID.
func (s *SmartContract) ConsultarTransacao(ctx contractapi.TransactionContextInterface, id string) (*Transacao, error) {
	// GetState busca um registro no ledger pela sua chave (ID)
	transacaoJSON, err := ctx.GetStub().GetState(id)
	if err != nil {
		return nil, fmt.Errorf("falha ao ler do world state: %v", err)
	}
	if transacaoJSON == nil {
		return nil, fmt.Errorf("a transação %s não existe", id)
	}

	var transacao Transacao
	// Converte o resultado (que está em JSON) de volta para a struct Transacao
	err = json.Unmarshal(transacaoJSON, &transacao)
	if err != nil {
		return nil, err
	}

	return &transacao, nil
}

// ConsultarHistoricoVeiculo retorna todas as transações de um veículo específico.
// Esta é a função de consulta mais importante para seu caso de uso.
// IMPORTANTE: Requer que a rede Fabric esteja configurada com CouchDB como banco de dados de estado.
func (s *SmartContract) ConsultarHistoricoVeiculo(ctx contractapi.TransactionContextInterface, idVeiculo string) ([]*Transacao, error) {
	// Esta string define uma "rich query" que busca em todos os documentos
	// por aqueles que têm o campo "IDVeiculo" com o valor desejado.
	queryString := fmt.Sprintf(`{"selector":{"IDVeiculo":"%s"}}`, idVeiculo)

	// GetQueryResult executa a consulta rica no ledger
	resultsIterator, err := ctx.GetStub().GetQueryResult(queryString)
	if err != nil {
		return nil, err
	}
	defer resultsIterator.Close() // Garante que o iterador será fechado ao final da função

	var transacoes []*Transacao
	// Itera sobre os resultados da consulta
	for resultsIterator.HasNext() {
		queryResponse, err := resultsIterator.Next()
		if err != nil {
			return nil, err
		}

		var transacao Transacao
		err = json.Unmarshal(queryResponse.Value, &transacao)
		if err != nil {
			return nil, err
		}
		transacoes = append(transacoes, &transacao)
	}

	return transacoes, nil
}

// TransacaoExists é uma função auxiliar para verificar se uma transação já existe.
func (s *SmartContract) TransacaoExists(ctx contractapi.TransactionContextInterface, id string) (bool, error) {
	transacaoJSON, err := ctx.GetStub().GetState(id)
	if err != nil {
		return false, fmt.Errorf("falha ao ler do world state: %v", err)
	}

	// Se o resultado não for nulo, significa que a transação existe.
	return transacaoJSON != nil, nil
}

/*package chaincode

import (
	"encoding/json"
	"fmt"

	"github.com/hyperledger/fabric-contract-api-go/v2/contractapi"
)

// SmartContract provides functions for managing an Asset
type SmartContract struct {
	contractapi.Contract
}

// Asset describes basic details of what makes up a simple asset
// Insert struct field in alphabetic order => to achieve determinism across languages
// golang keeps the order when marshal to json but doesn't order automatically
type Asset struct {
	AppraisedValue int    `json:"AppraisedValue"`
	Color          string `json:"Color"`
	ID             string `json:"ID"`
	Owner          string `json:"Owner"`
	Size           int    `json:"Size"`
}

// InitLedger adds a base set of assets to the ledger
func (s *SmartContract) InitLedger(ctx contractapi.TransactionContextInterface) error {
	assets := []Asset{
		{ID: "asset1", Color: "blue", Size: 5, Owner: "Tomoko", AppraisedValue: 300},
		{ID: "asset2", Color: "red", Size: 5, Owner: "Brad", AppraisedValue: 400},
		{ID: "asset3", Color: "green", Size: 10, Owner: "Jin Soo", AppraisedValue: 500},
		{ID: "asset4", Color: "yellow", Size: 10, Owner: "Max", AppraisedValue: 600},
		{ID: "asset5", Color: "black", Size: 15, Owner: "Adriana", AppraisedValue: 700},
		{ID: "asset6", Color: "white", Size: 15, Owner: "Michel", AppraisedValue: 800},
	}

	for _, asset := range assets {
		assetJSON, err := json.Marshal(asset)
		if err != nil {
			return err
		}

		err = ctx.GetStub().PutState(asset.ID, assetJSON)
		if err != nil {
			return fmt.Errorf("failed to put to world state. %v", err)
		}
	}

	return nil
}

// CreateAsset issues a new asset to the world state with given details.
func (s *SmartContract) CreateAsset(ctx contractapi.TransactionContextInterface, id string, color string, size int, owner string, appraisedValue int) error {
	exists, err := s.AssetExists(ctx, id)
	if err != nil {
		return err
	}
	if exists {
		return fmt.Errorf("the asset %s already exists", id)
	}

	asset := Asset{
		ID:             id,
		Color:          color,
		Size:           size,
		Owner:          owner,
		AppraisedValue: appraisedValue,
	}
	assetJSON, err := json.Marshal(asset)
	if err != nil {
		return err
	}

	return ctx.GetStub().PutState(id, assetJSON)
}

// ReadAsset returns the asset stored in the world state with given id.
func (s *SmartContract) ReadAsset(ctx contractapi.TransactionContextInterface, id string) (*Asset, error) {
	assetJSON, err := ctx.GetStub().GetState(id)
	if err != nil {
		return nil, fmt.Errorf("failed to read from world state: %v", err)
	}
	if assetJSON == nil {
		return nil, fmt.Errorf("the asset %s does not exist", id)
	}

	var asset Asset
	err = json.Unmarshal(assetJSON, &asset)
	if err != nil {
		return nil, err
	}

	return &asset, nil
}

// UpdateAsset updates an existing asset in the world state with provided parameters.
func (s *SmartContract) UpdateAsset(ctx contractapi.TransactionContextInterface, id string, color string, size int, owner string, appraisedValue int) error {
	exists, err := s.AssetExists(ctx, id)
	if err != nil {
		return err
	}
	if !exists {
		return fmt.Errorf("the asset %s does not exist", id)
	}

	// overwriting original asset with new asset
	asset := Asset{
		ID:             id,
		Color:          color,
		Size:           size,
		Owner:          owner,
		AppraisedValue: appraisedValue,
	}
	assetJSON, err := json.Marshal(asset)
	if err != nil {
		return err
	}

	return ctx.GetStub().PutState(id, assetJSON)
}

// DeleteAsset deletes an given asset from the world state.
func (s *SmartContract) DeleteAsset(ctx contractapi.TransactionContextInterface, id string) error {
	exists, err := s.AssetExists(ctx, id)
	if err != nil {
		return err
	}
	if !exists {
		return fmt.Errorf("the asset %s does not exist", id)
	}

	return ctx.GetStub().DelState(id)
}

// AssetExists returns true when asset with given ID exists in world state
func (s *SmartContract) AssetExists(ctx contractapi.TransactionContextInterface, id string) (bool, error) {
	assetJSON, err := ctx.GetStub().GetState(id)
	if err != nil {
		return false, fmt.Errorf("failed to read from world state: %v", err)
	}

	return assetJSON != nil, nil
}

// TransferAsset updates the owner field of asset with given id in world state, and returns the old owner.
func (s *SmartContract) TransferAsset(ctx contractapi.TransactionContextInterface, id string, newOwner string) (string, error) {
	asset, err := s.ReadAsset(ctx, id)
	if err != nil {
		return "", err
	}

	oldOwner := asset.Owner
	asset.Owner = newOwner

	assetJSON, err := json.Marshal(asset)
	if err != nil {
		return "", err
	}

	err = ctx.GetStub().PutState(id, assetJSON)
	if err != nil {
		return "", err
	}

	return oldOwner, nil
}

// GetAllAssets returns all assets found in world state
func (s *SmartContract) GetAllAssets(ctx contractapi.TransactionContextInterface) ([]*Asset, error) {
	// range query with empty string for startKey and endKey does an
	// open-ended query of all assets in the chaincode namespace.
	resultsIterator, err := ctx.GetStub().GetStateByRange("", "")
	if err != nil {
		return nil, err
	}
	defer resultsIterator.Close()

	var assets []*Asset
	for resultsIterator.HasNext() {
		queryResponse, err := resultsIterator.Next()
		if err != nil {
			return nil, err
		}

		var asset Asset
		err = json.Unmarshal(queryResponse.Value, &asset)
		if err != nil {
			return nil, err
		}
		assets = append(assets, &asset)
	}

	return assets, nil
}*/
